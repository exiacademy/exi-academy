EXI ACADEMY – AMULET: MONTÁŽ A SERVIS BICYKLOV

ID: train_e2d7c873ac68
categoryId: summer
categoryId: summer

Obsah balíčka:
- metadata.json – názov, ID, kategória a presne dve kapitoly
- index.html – responzívne školenie s prepínacími oknami kapitol
- assets/ – vyhradený priečinok (v tejto verzii nie sú potrebné lokálne obrázky)

Kapitoly:
1. Montáž bicyklov AMULET – 10 videí
2. Servis a základné opravy – 6 videí

Obrázky v kartách sú náhľady z YouTube (i.ytimg.com); po kliknutí na obrázok sa otvorí príslušné video. Náhľady aj prehrávanie vyžadujú internet.

Poznámka k názvom servisných videí 4–6:
Ich presné názvy sa nepodarilo nezávisle overiť, preto sú označené neutrálne ako „Servisný postup – video 4/5/6“ a text túto neistotu výslovne uvádza.

Technická kontrola vykonaná lokálne:
- UTF-8 dekódovanie a platný JSON: kontrolované
- HTML parser bez fatálnej chyby parsovania: kontrolované
- odkazy na 16 videí a párovanie ID náhľadov: kontrolované
- dve kapitoly a prepínanie cez tlačidlá: kontrolované statickou kontrolou
- ZIP štruktúra: kontrolovaná po vytvorení

Obmedzenia:
- Nebol spustený import v samotnej aplikácii EXI Academy ani test na fyzickom Android WebView.
- categoryId „summer“ a subcategoryId „cycling“ vychádzajú zo vzorového balíčka Bicykle dostupného v projekte; nemožno garantovať, že každá verzia aplikácie používa rovnaké ID.
- Dostupnosť jednotlivých videí a náhľadov závisí od YouTube a internetového pripojenia.
